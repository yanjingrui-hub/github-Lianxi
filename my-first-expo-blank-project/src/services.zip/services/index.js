// src/services/api/index.ts
export * from "./request"; // 暴露 request.ts 中的方法
